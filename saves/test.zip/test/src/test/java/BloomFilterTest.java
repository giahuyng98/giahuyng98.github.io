import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class BloomFilterTest {


  @Test
  public void test01() {
    BloomFilter bloomFilter = new BloomFilter(2);
    assertEquals(bloomFilter.add("huy"), true);
    assertEquals(bloomFilter.add("huy1"), true);
    assertEquals(bloomFilter.add("huy2"), true);

    assertEquals(bloomFilter.contains("huy"), true);
    assertEquals(bloomFilter.contains("huy1"), true);
    assertEquals(bloomFilter.contains("huy2"), true);
    assertEquals(bloomFilter.contains("huy3"), false);
  }


}