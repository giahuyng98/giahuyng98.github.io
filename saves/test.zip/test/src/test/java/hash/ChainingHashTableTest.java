package hash;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class ChainingHashTableTest {

  @Test
  public void increaseSizeTest() {
    ChainingHashTable<String, String> hashTable = new ChainingHashTable<>();
    assertEquals(hashTable.size(), 0);
    hashTable.add("key01", "value01");
    assertEquals(hashTable.size(), 1);
    hashTable.add("key02", "value02");
    assertEquals(hashTable.size(), 2);
    hashTable.add("key01", "value03");
    assertEquals(hashTable.size(), 2);

  }

  @Test
  public void getValueTest() {
    ChainingHashTable<String, String> hashTable = new ChainingHashTable<>();
    assertEquals(hashTable.get("key00"), null);
    hashTable.add("key01", "value01");
    assertEquals(hashTable.get("key01"), "value01");
    hashTable.add("key01", "value02");
    assertEquals(hashTable.get("key01"), "value02");
  }
}