package dictionary;

import org.junit.Test;

import static org.junit.Assert.*;

public class BloomFilterTest {
  @Test
  public void test01() {
    BloomFilter bloomFilter = new BloomFilter(10);
    assertTrue(bloomFilter.add("huy"));
    assertTrue(bloomFilter.add("huy1"));
    assertTrue(bloomFilter.add("huy2"));

    assertTrue(bloomFilter.contains("huy"));
    assertTrue(bloomFilter.contains("huy1"));
    assertTrue(bloomFilter.contains("huy2"));
    assertFalse(bloomFilter.contains("huy3"));
  }


}