package dictionary;

import org.junit.Test;

import static org.junit.Assert.*;

public class TrieRemovableTest {

    public interface MyStyle extends Dictionary, Sizable, Removable {

    }

    public  <T extends Dictionary & Sizable & Removable> void test(T trie ) {
        assertEquals(trie.size(), 0);
        trie.add("abc");
        assertEquals(trie.size(), 1);
        trie.add("def");
        assertEquals(trie.size(), 2);

        assertTrue(trie.contains("abc"));
        assertFalse(trie.contains("ab"));
        assertFalse(trie.contains("a"));

        assertTrue(trie.contains("def"));
        trie.remove("def");

        assertFalse(trie.contains("def"));
        assertEquals(trie.size(), 1);

    }

    public void testMyStyle( MyStyle trie ) {
        trie.add("abc");
        trie.add("def");

        assertEquals(trie.contains("abc"), true);
        assertEquals(trie.contains("ab"), false);
        assertEquals(trie.contains("a"), false);

        assertEquals(trie.contains("def"), true);
        assertEquals(trie.size(), 2);

        trie.remove("def");

        assertEquals(trie.contains("def"), false);
        assertEquals(trie.size(), 1);
    }

    @Test
    public void test() {
        test( new TrieSizable() );
//        testMyStyle( new TrieAdapter() );
    }

    public class TrieAdapter extends TrieSizable implements MyStyle {

    }
}