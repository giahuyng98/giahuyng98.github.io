package dictionary;

import dictionary.Trie;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


public class TrieTest {

  @Test
  public void containsTest() {
    Trie trie = new TrieSizable();
    trie.add("abc");
    trie.add("def");

    assertEquals(trie.contains("abc"), true);
    assertEquals(trie.contains("ab"), false);
    assertEquals(trie.contains("a"), false);

    assertEquals(trie.contains("def"), true);

  }

  @Test
  public void recommendWordsTest() {
    Trie trie = new Trie();

    String[] words = {"nguyen", "gia", "huy", "first", "vng", "fresher", "nguoi", "meo", "ngu"};
    for (String word : words) {
      trie.add(word);
    }
    assertTrue(trie.getSimilarWords("ng").size() > 2);
  }
}