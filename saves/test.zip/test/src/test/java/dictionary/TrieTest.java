package dictionary;

import dictionary.Trie;
import org.junit.Test;
import static org.junit.Assert.assertEquals;


public class TrieTest {

  @Test
  public void test() {
    Trie trie = new Trie();
    trie.add("abc");
    trie.add("def");

    assertEquals(trie.contains("abc"), true);
    assertEquals(trie.contains("ab"), false);
    assertEquals(trie.contains("a"), false);

    assertEquals(trie.contains("def"), true);

  }
}