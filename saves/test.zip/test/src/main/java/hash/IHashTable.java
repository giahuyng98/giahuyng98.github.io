package hash;

public interface IHashTable<K, V> {
    public int size();
    public void add(K key, V value);
    public V get(K key);
}
