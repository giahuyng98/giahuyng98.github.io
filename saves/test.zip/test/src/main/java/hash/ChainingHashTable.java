package hash;

public class ChainingHashTable<K, V> implements IHashTable<K, V>{

  private static final float MAX_LOAD_FACTOR = 0.75f;
  private int capacity = 124147;
  private LinkedList<Pair<K, V>>[] buckets;
  private int size;

  public ChainingHashTable() {
    size = 0;
    buckets = new LinkedList[capacity];
  }

  private int position(K key) {
    int hash = key.hashCode() % capacity;
    if (hash < 0) hash += capacity;
    return hash;
  }

  public void add(K key, V value) {
    int position = position(key);
    if (buckets[position] == null) {
      buckets[position] = new LinkedList<>();
    } else {
      for (Pair<K, V> pair : buckets[position]) {
        if (pair.key == key) {
          pair.value = value;
          return;
        }
      }
    }
    addNew(position, key, value);
  }

  private void addNew(int position, K key, V value) {
    if (size / capacity > MAX_LOAD_FACTOR) {
      extend();
      addNew(position, key, value);
    } else {
      buckets[position].add(new Pair<>(key, value));
      ++size;
    }

  }

  private void extend() {
    int newCapacity = capacity << 1;
    LinkedList<Pair<K, V>>[] newData = new LinkedList[newCapacity];
    // TODO: copy data

  }

  public V get(K key) {
    int position = position(key);
    if (buckets[position] == null) {
      return null;
    }
    for (Pair<K, V> pair : buckets[position]) {
      if (pair.key == key) {
        return pair.value;
      }
    }
    return null;
  }

  public int size() {
    return this.size;
  }

  public static void main(String[] args) {
    ChainingHashTable<String, String> hashTable = new ChainingHashTable<>();
    hashTable.add("nguyen", "1");
    System.out.println("new size: " + hashTable.size());

    hashTable.add("huy", "3");
    System.out.println("new size: " + hashTable.size());

    hashTable.add("gia", "2");
    System.out.println("new size: " + hashTable.size());

    System.out.println(hashTable.get("nguyen"));
    System.out.println(hashTable.get("gia"));
    hashTable.add("gia", "new value");
    System.out.println(hashTable.get("gia"));
    System.out.println(hashTable.get("huy"));
    System.out.println(hashTable.get("should be null"));
  }
}

class Pair<K, V> {
  public K key;
  public V value;

  public Pair(K key, V value) {
    this.key = key;
    this.value = value;
  }
}
//
//class HashTableIterator<K, V> implements Iterator<Pair<K, V>> {
//
//  public HashTableIterator(HashTable<K, V> table) {}
//
//  @Override
//  public boolean hasNext() {
//    return false;
//  }
//
//  @Override
//  public Pair<K, V> next() {
//    return null;
//  }
//}
