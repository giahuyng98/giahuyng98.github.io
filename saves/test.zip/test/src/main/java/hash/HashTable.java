package hash;

public interface HashTable<K, V> {
    public int size();
    public void add(K key, V value);
    public V get(K key);
}
