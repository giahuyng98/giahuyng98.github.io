package hash;

import java.util.Iterator;

public class LinkedList<T> implements Iterable<T> {
  private LinkedListNode<T> head = null, tail = null;

  public void add(T value) {
    if (head == null) {
      head = tail = new LinkedListNode(value);
    } else {
      tail.next = new LinkedListNode(value);
      tail = tail.next;
    }
  }

  @Override
  public Iterator iterator() {
    return new LinkedListIterator(head);
  }

  public static void main(String[] args) {
    LinkedList<String> list = new LinkedList<>();
    list.add("nguyen");
    list.add("gia");
    list.add("huy");
    for(String s : list) {
      System.out.println(s);
    }
  }
}

class LinkedListIterator<T> implements Iterator<T> {

  private LinkedListNode<T> current;

  public LinkedListIterator(LinkedListNode<T> head) {
    this.current = head;
  }

  @Override
  public boolean hasNext() {
    return current != null;
  }

  @Override
  public T next() {
    T value = current.value;
    current = current.next;
    return value;
  }
}

class LinkedListNode<T> {
  public T value;
  public LinkedListNode next;

  public LinkedListNode(T value) {
    this.value = value;
    this.next = null;
  }
}