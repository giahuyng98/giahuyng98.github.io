package oop;

public class Animal {
  private String name;

  public Animal() {}

  public Animal(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void say() {
    System.out.println("Animal say: what??");
  }

  public static void main(String[] args) {
    Animal animal = new Animal();
    animal.say();

    animal = new Dog();
    animal.say();
    animal = new Cat();

    Cat w = (Cat)animal;
    w.whatever();
  }
}
