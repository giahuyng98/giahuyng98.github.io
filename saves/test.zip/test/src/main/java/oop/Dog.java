package oop;

public class Dog extends Animal {

  @Override
  public void say() {
    System.out.println("Dog barks...");
  }
}
