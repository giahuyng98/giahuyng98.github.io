package oop;

 public class Cat extends Animal{
    private String type;

    @Override
    public void say() {
        System.out.println("Cat say meo");
    }

    public void whatever() {
        System.out.println("sadfsdaf");
    }
}
