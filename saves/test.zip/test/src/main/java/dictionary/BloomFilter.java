package dictionary;

public class BloomFilter implements IDictionary  {

    static final private int INT_BIT_SIZE = 32;
    static final private int NUMBER_OF_HASH_FUNCTION = 5;

    private final int[] bucket;
    private final int size;

    public BloomFilter(int size) {
        this.size = size;
        bucket = new int[(size + INT_BIT_SIZE - 1) / INT_BIT_SIZE];
    }

    // TODO: better hash function
    private int[] getListHash(String word) {
        int[] result = new int[NUMBER_OF_HASH_FUNCTION];
        int hashInitValue = word.hashCode();
        for (int i = 0; i < NUMBER_OF_HASH_FUNCTION; ++i) {
            if (hashInitValue < 0) hashInitValue = -hashInitValue;
            result[i] = hashInitValue;
            hashInitValue = 31 * hashInitValue;
        }
        return result;
    }

    public boolean contains(String word) {
        for(int hash : getListHash(word)) {
            if (!getBit(hash % size)) {
                return false;
            }
        }
        return true;
    }

    public boolean add(String word) {
        for(int hash : getListHash(word)) {
            setBit(hash % size);
        }
        return true;
    }


    private void setBit(int th){
        int div = th / INT_BIT_SIZE;
        int mod = th % INT_BIT_SIZE;
        bucket[div] = onBit(mod, bucket[div]);
    }

    private boolean getBit(int th) {
        int div = th / INT_BIT_SIZE;
        int mod = th % INT_BIT_SIZE;
        return (bucket[div] >> mod & 1) == 1;
    }

    private static int onBit(int th, int bit) {
        return (bit | (1 << th));
    }

}
