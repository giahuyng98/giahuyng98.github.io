package dictionary;

public class TrieSizable extends TrieRemovable implements Sizable{
    private int size = 0;

    @Override
    public int size() {
        return size;
    }


    @Override
    public boolean remove(String word) {
        boolean res = super.remove(word);
        if (res) --size;
        return res;
    }

    @Override
    public boolean add(String word) {
        boolean res = super.add(word);
        if (res) {
            ++size;
        }
        return res;
    }
}
