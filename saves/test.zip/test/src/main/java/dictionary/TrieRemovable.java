package dictionary;

public class TrieRemovable extends Trie implements Removable {
    public boolean remove(String word) {
        TrieNode cur = getRoot();
        for(int i = 0; i < word.length(); ++i) {
            if (cur.getChild().get(word.charAt(i)) == null) {
                return false;
            }
            cur = cur.getChild().get(word.charAt(i));
        }
        if (cur != null && cur.getCount() > 0) {
            cur.decrCount();
            return true;
        }
        return false;
    }
}
