package dictionary;

import java.util.Map;

public interface TrieNode {
    Map<Character, Trie.Node> getChild();
    int getCount();
    int incrCount();
    int decrCount();
}
