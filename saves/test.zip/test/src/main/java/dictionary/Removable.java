package dictionary;

public interface Removable {
    public boolean remove(String word) ;
}
