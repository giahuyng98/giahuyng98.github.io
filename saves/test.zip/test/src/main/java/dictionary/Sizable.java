package dictionary;


public interface Sizable {
    public int size();
}
