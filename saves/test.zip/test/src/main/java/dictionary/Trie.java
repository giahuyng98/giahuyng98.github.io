package dictionary;

import java.util.*;

public class Trie implements Dictionary {

    private static final int MAX_RECOMMEND_WORD = 5;
    private final TrieNode root;

    public Trie() {
        root = new Node();
    }

    public Trie(TrieNode root ) {
        if (root == null) {
            root = new Node();
        }
        this.root = root;
    }

    public static class Node implements TrieNode{
        public Map<Character, Node> child;
        public int count;

        public Node() {
            child = new HashMap<>();
            count = 0;
        }

        @Override
        public Map<Character, Node> getChild() {
            return child;
        }

        @Override
        public int getCount() {
            return count;
        }

        @Override
        public int incrCount() {
            return ++count;
        }

        @Override
        public int decrCount() {
            return --count;
        }
    }

    public TrieNode getRoot() {
        return root;
    }


    public boolean add(String word) {
        TrieNode cur = root;
        for (int i = 0; i < word.length(); ++i) {
            Character c = word.charAt(i);
            if (!cur.getChild().containsKey(c)) {
                cur.getChild().put(c, new Node());
            }
            cur = cur.getChild().get(c);
        }
        return (cur.incrCount() == 1);
    }

    public boolean contains(String word) {
        TrieNode lastNode = getLastNode(word);
        return !(lastNode == null || lastNode.getCount() == 0);
    }

    private TrieNode getLastNode(String word) {
        TrieNode cur = root;
        for (int i = 0; i < word.length(); ++i) {
            Character c = word.charAt(i);
            if (!cur.getChild().containsKey(c)) {
                return null;
            }
            cur = cur.getChild().get(c);
        }
        return cur;
    }

    private void dfs(Node cur, String curWord, List<String> words) {
        if (cur == null) {
            return;
        }

        if (words.size() == MAX_RECOMMEND_WORD) {
            return;
        }
        if (cur.count > 0) {
            words.add(curWord);
        }

        for(Map.Entry<Character, Node> entry : cur.child.entrySet()) {
            dfs(entry.getValue(), curWord + entry.getKey(), words);
        }
    }

    static class NodeStringPair{
        public TrieNode node;
        public String str;

        public NodeStringPair(TrieNode node, String str) {
            this.node = node;
            this.str = str;
        }
    }

    private void bfs(TrieNode cur, String curWord, List<String> words) {
        Queue<NodeStringPair> queue = new LinkedList<>();
        queue.add(new NodeStringPair(cur, curWord));
        int recommendCount = 0;
        while (!queue.isEmpty() && recommendCount < MAX_RECOMMEND_WORD) {
            NodeStringPair top = queue.poll();
            if (top.node.getCount() > 0) {
                ++recommendCount;
                words.add(top.str);
            }
            for(Map.Entry<Character, Node> entry : top.node.getChild().entrySet()) {
                queue.add(new NodeStringPair(entry.getValue(),top.str + entry.getKey()));
            }
        }
    }

    public List<String> getSimilarWords(String word) {
        ArrayList<String> result = new ArrayList<>();
//        dfs(getLastNode(word), word, result);
        bfs(getLastNode(word), word, result);
        return result;
    }

    public static void main(String[] args) {

    }
}
