package dictionary;

public interface IDictionary {
    public boolean contains(String word);
    public boolean add(String word);
}
