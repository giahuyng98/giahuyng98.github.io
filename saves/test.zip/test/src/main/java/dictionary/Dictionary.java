package dictionary;

public interface Dictionary {
    public boolean contains(String word);
    public boolean add(String word);
}



