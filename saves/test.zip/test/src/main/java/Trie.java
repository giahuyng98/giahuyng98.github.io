import java.util.*;

public class Trie implements IDictionary {

    private static final int MAX_RECOMMENT_WORD = 5;

    class Node {
        HashMap<Character, Node> child;
        int count;

        public Node() {
            child = new HashMap<>();
            count = 0;
        }
    }

    private Node root = new Node();


    public boolean add(String word) {
        Node cur = root;
        for (int i = 0; i < word.length(); ++i) {
            Character c = word.charAt(i);
            if (!cur.child.containsKey(c)) {
                cur.child.put(c, new Node());
            }
            cur = cur.child.get(c);
        }
        return (cur.count++ == 0);
    }

    public boolean contains(String word) {
        Node lastNode = getLastNode(word);
        return !(lastNode == null || lastNode.count == 0);
    }

    private Node getLastNode(String word) {
        Node cur = root;
        for (int i = 0; i < word.length(); ++i) {
            Character c = word.charAt(i);
            if (!cur.child.containsKey(c)) {
                return null;
            }
            cur = cur.child.get(c);
        }
        return cur;
    }

    private void dfs(Node cur, String curWord, List<String> words) {
        if (cur == null) {
            return;
        }

        if (words.size() == MAX_RECOMMENT_WORD) {
            return;
        }
        if (cur.count > 0) {
            words.add(curWord);
        }

        for(Map.Entry<Character, Node> entry : cur.child.entrySet()) {
            dfs(entry.getValue(), curWord + entry.getKey(), words);
        }
    }

    static class NodeStringPair{
        public Node node;
        public String str;

        public NodeStringPair(Node node, String str) {
            this.node = node;
            this.str = str;
        }
    }

    private void bfs(Node cur, String curWord, List<String> words) {
        Queue<NodeStringPair> queue = new LinkedList<>();
        queue.add(new NodeStringPair(cur, curWord));
        int recommendCount = 0;
        while (!queue.isEmpty() && recommendCount < MAX_RECOMMENT_WORD) {
            NodeStringPair top = queue.poll();
            if (top.node.count > 0) {
                ++recommendCount;
                words.add(top.str);
            }
            for(Map.Entry<Character, Node> entry : top.node.child.entrySet()) {
                queue.add(new NodeStringPair(entry.getValue(),top.str + entry.getKey()));
            }
        }
    }

    public List<String> getSimilarWords(String word) {
        ArrayList<String> result = new ArrayList<>();
//        dfs(getLastNode(word), word, result);
        bfs(getLastNode(word), word, result);
        return result;
    }

    public static void main(String[] args) {
        Trie trie = new Trie();

        String[] words = {"nguyen", "gia", "huy", "first", "vng", "fresher", "nguoi", "meo", "ngu"};
        for (String word : words) {
            trie.add(word);
        }
        System.out.println(trie.contains("gia"));
        System.out.println(trie.getSimilarWords("ng"));
    }
}
