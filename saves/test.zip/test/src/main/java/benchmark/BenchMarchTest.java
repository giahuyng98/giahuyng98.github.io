package benchmark;

import dictionary.Trie;
import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.runner.Runner;
import org.openjdk.jmh.runner.RunnerException;
import org.openjdk.jmh.runner.options.Options;
import org.openjdk.jmh.runner.options.OptionsBuilder;

public class BenchMarchTest {
  public static void main(String[] args) throws  RunnerException {
//    org.openjdk.jmh.Main.main(args);

    Options opt = new OptionsBuilder()
            .include(BenchMarchTest.class.getSimpleName())
            .warmupIterations(1)
            .measurementIterations(1)
            .threads(2)
            .forks(1)
            .build();
    new Runner(opt).run();
  }

  @Benchmark
  @BenchmarkMode(Mode.Throughput)
  public void benchTrie(ExecutionPlan plan) {
    while (plan.iterations--> 0) {
      plan.trie.add("abcdef");
    }
  }

  @State(Scope.Benchmark)
  public static class ExecutionPlan {
    @Param({ "100", "200", "300", "500", "1000" })
    public int iterations;

    public Trie trie;

    @Setup(Level.Invocation)
    public void setUp() {
      trie = new Trie();
    }
  }

//  @Fork(value = 1, warmups = 1)
//  @Benchmark
//  @BenchmarkMode(Mode.AverageTime)
//  public void bloomFilterAddTest() {}
//
//  public static class BenchMarkParams {
//    @Param({"1", "20"})
//  }

  public void func(Trie dic) {
    dic.contains("a");
  }
}
