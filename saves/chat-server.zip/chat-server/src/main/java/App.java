import models.User;
import utils.ConnectionUtil;

import java.sql.*;
import java.util.Date;
import java.util.Scanner;

public class App {

  private Scanner sc = new Scanner(System.in);
  private Connection conn = ConnectionUtil.getConnection();
  private User user;



  private boolean login() {
    final String LOGIN_SQL =
          "SELECT id, username, fullname, email from users where username = ? and password = ?";
    System.out.println("::::::::Chat Application - Login ::::::::");

    System.out.print("username: ");
    String username = sc.next();
    System.out.print("password: ");
    String password = sc.next();

    try {
      PreparedStatement pstm = conn.prepareStatement(LOGIN_SQL);
      pstm.setString(1, username);
      pstm.setString(2, password);

      ResultSet rs = pstm.executeQuery();
      if (rs.next()) {
        user = new User(
                rs.getInt(1),
                rs.getString(2),
                rs.getString(3),
                rs.getString(4));
        return true;
      }

      System.out.println("\033[31mError: Wrong username or password \033[0m");

    } catch (SQLException throwables) {
      throwables.printStackTrace();
      System.err.println("Error: System error");
    }

    return false;
  }

  private void start() {
    System.out.println("::::::::Chat Application - Start ::::::::");
    int attempt = 0;
    while (true) {
      if (login()) break;
      if (++attempt == 5) {
        System.err.println("Too many tries!!!");
        return;
      }
    }

    mainMenu();
  }

  private void mainMenu() {
    System.out.println("::::::::Chat Application - Main Menu ::::::::");
    System.out.println("Welcome \033[32m" + user.getFullName() + "\033[0m");
    System.out.println("1. Friends");
    System.out.println("2. Messages");
    System.out.println("3. Groups");
    System.out.println("0. Exit");
    int request = Integer.parseInt(sc.next());
    switch (request) {
      case 1:
        friendsMenu();
        return;
      case 2:
        messagesMenu();
        return;
      case 3:
        groupsMenu();
        return;
      case 0:
        return;
      default:
        return;
    }
  }

  private void groupsMenu() {}

  private Integer getChatId(Integer from, Integer to) {
    final String sql = "SELECT id FROM users_chat WHERE from = ? and to = ?";
    try {
      PreparedStatement pstm = conn.prepareStatement(sql);
      pstm.setInt(1, from);
      pstm.setInt(2, to);

      ResultSet rs = pstm.executeQuery();
      if (rs.next()) {
        return rs.getInt(1);
      } else {
        final String newChat = "INSERT INTO users_chat(from, to) values(?, ?)";
        conn.prepareStatement(newChat).executeQuery();
        return getChatId(from, to);
      }
    } catch (SQLException throwables) {
      throwables.printStackTrace();
    }
    return null;
  }

  private Integer newMessage(String content, Integer createBy, Integer type) {
    final String sql = "INSERT INTO messages(type, content, status, create_at, create_by) VALUES(?,?,?,?,?)";
    try {
      PreparedStatement pstm = conn.prepareStatement(sql);
      pstm.setInt(1, 0);
      pstm.setString(2, content);
      pstm.setInt(3, 0);
      pstm.setString(4,  new Date().toString());
      pstm.setInt(5, createBy);
      ResultSet rs = pstm.executeQuery();
      if (rs.next()) {
        return rs.getInt(1);
      }
    } catch (SQLException throwables) {
      throwables.printStackTrace();
    }
    return null;
  }

  private void sendMessageToUser(Integer toUserId, String message) {
    Integer chatId = getChatId(user.getId(), toUserId);
  }

  private void sendMessageToGroup(Integer groupId, String message) {

  }


  private void messagesMenu() {
    while (true) {
      System.out.println("::::::::Chat Application - Messages Menu ::::::::");
      System.out.println("1. My messages");
      System.out.println("2. New messages");
      System.out.println("0. Back");
      int request = Integer.parseInt(sc.next());
      switch (request) {
        case 1:
        {
          break;
        }

        case 2:
        {

          final String sql = "SELECT id FROM users WHERE username = ?";
          System.out.print("Enter username to sent message: ");
          String to = sc.next();
          try {
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, to);
            ResultSet rs = pstm.executeQuery();
            if (rs.next()) {
              Integer toUserId = rs.getInt(1);
              if (toUserId.equals(user.getId())) {
                  System.err.println("Can't sent message to yourself!!!");
              } else {
                System.out.print("Enter your message: ");
                String message = sc.nextLine();
                sendMessageToUser(toUserId, message);
                System.out.println("Done");
              }
            }
          } catch (SQLException throwables) {
            throwables.printStackTrace();
          }
          break;
        }
        case 0:
          mainMenu();
          return;
        default:
          return;
      }
    }
  }

  private void listMyFriends() {
    final String sql =
            "SELECT username, fullname\n" +
            "FROM users u\n" +
            "JOIN friends f\n" +
            "ON u.id = f.friend_id\n" +
            "WHERE f.users_id = ?";

    try {
      PreparedStatement pstm = conn.prepareStatement(sql);
      pstm.setInt(1, user.getId());
      ResultSet rs = pstm.executeQuery();
      int cnt = 0;
      System.out.format("+---+------------------+--------------------+\n");
      System.out.format("|   |     Username     |     Full name      |\n");
      System.out.format("+---+------------------+--------------------+\n");


      while (rs.next()) {
        String username = rs.getString(1);
        String fullname = rs.getString(2);

        System.out.format("|%3d|%18s|%20s|\n", ++cnt, username, fullname);
      }
      System.out.format("+---+------------------+--------------------+\n");

    } catch (SQLException throwables) {
      throwables.printStackTrace();
    }

  }

  private void friendsMenu() {
    while (true) {
      System.out.println("::::::::Chat Application - Friend Menu ::::::::");
      System.out.println("1. List my friends");
      System.out.println("2. Friends request");
      System.out.println("3. Add a friend");
      System.out.println("0. Back");
      int request = Integer.parseInt(sc.next());
      switch (request) {
        case 1:
          {
            listMyFriends();
            break;
          }

        case 2:
          break;
        case 3:
          break;
        case 0:
          mainMenu();
          return;
        default:
          return;
      }
    }
  }

  public static void main(String[] args) {
    App app = new App();
    app.start();
//        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
//        Session session = sessionFactory.openSession();
//
//        try {
//          session.beginTransaction();
//
//          for(int i = 1; i <= 10; ++i) {
//            User user = new User("name " + i, "user" + i, "email" + i + "@email.com", "123");
//            session.save(user);
//          }
//
//          session.getTransaction().commit();
//          session.close();

//          String sql = "SELECT u FROM " + User.class.getName() + " u";
//          Query query = session.createQuery(sql);
//
//          List<User> users = query.getResultList();
//          System.out.println("Users size: " + users.size());
//          for (User user : users) {
//            System.out.println(user);
//          }
//        } catch (Exception ex) {
//          ex.printStackTrace();
//        }
  }
}
