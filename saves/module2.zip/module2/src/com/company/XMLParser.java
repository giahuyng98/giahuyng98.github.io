package com.company;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;


public class XMLParser {

    DocumentBuilderFactory factory = null;
    DocumentBuilder builder = null;
    IDictionary dic;

    public XMLParser(IDictionary dic, String path) {
        try {
            factory = DocumentBuilderFactory.newInstance();
            builder = factory.newDocumentBuilder();
            this.dic = dic;

            File file = new File(path);
            if (!file.exists()) {
                System.out.println("File not exists");
                return;
            }

            if (file.isDirectory()) {
                for(File f : file.listFiles()) {
                    parseFile(f);
                }
            } else {
                parseFile(file);
            }
        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }
    }

    private void parseFile(File file) throws IOException, SAXException {
        Document document = builder.parse(file);
        document.getDocumentElement().normalize();

        Element root = document.getDocumentElement();
        NodeList nodeList = document.getElementsByTagName("post");

        for (int i = 0; i < nodeList.getLength(); ++i) {
            Node node = nodeList.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) node;
                String line = element.getTextContent();
                String[] words = line.split("\\W+");
                for (String word : words) {
                    dic.add(word);
                }
            }
        }
    }

    public static void main(String[] args) {
        String path = "/home/giahuy/Downloads/blogs/999503.male.25.Internet.Cancer.xml";
        Trie trie = new Trie();

        XMLParser parser = new XMLParser(trie, path);

        System.out.println(trie.contains("i"));
    }
}
