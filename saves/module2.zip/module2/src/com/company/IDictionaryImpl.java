package com.company;

public class IDictionaryImpl implements IDictionary {
    @Override
    public boolean contains(String word) {
        return false;
    }

    @Override
    public boolean add(String word) {
        return false;
    }
}
